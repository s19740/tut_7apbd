﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace tutorial7.Models
{
    public class Enrollment
    {
        public int idEnrollment { get; set; }
        public string studies { get; set; }
        public int semester { get; set; }
        public int idStudy { get; set; }
    }
}
